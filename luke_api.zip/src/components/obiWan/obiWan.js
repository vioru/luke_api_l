import foto from "./error.jpg"

const Obi = () => {


    return (
        <div className="container col-12">

        {/* <h1>rt</h1> */}
        <img className="mb-4" src={foto} alt="obiwan"/>

        </div>
    );
}

export default Obi;
